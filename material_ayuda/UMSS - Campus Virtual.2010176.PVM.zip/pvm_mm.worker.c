/******************************************************************************
* PVM Matrix Multiply - C Version
* Worker Program 
* FILE: pvm_mm.worker.c
* DESCRIPTION: See pvm_mm.master.c
* PVM VERSION: 3.x
* LAST REVISED: 4/18/94 Blaise Barney
******************************************************************************/

#include <stdio.h>
#include <malloc.h>
#include "pvm3.h"       /* PVM version 3.0 include file */

#define NRA 62          /* number of rows in matrix A */
#define NCA 15          /* number of columns in matrix A */
#define NCB 7           /* number of columns in matrix B */

main() {
int wtid,               /* PVM task id of this worker program */
    mtid,               /* PVM task id of parent master program */
    mtype,              /* PVM message type */
    rows,               /* number of rows in matrix a sent to worker */
    offset,             /* starting position in matrix */
    rcode, i, j, k;     /* misc */
double a[NRA][NCA],     /* matrix A to be multiplied */
       b[NCA][NCB],     /* matrix B to be multiplied */
       c[NRA][NCB];     /* result matrix C */

/* enroll worker task */
wtid = pvm_mytid();

/* Receive message from master */
mtype = 1;                              /* set message type */
mtid = pvm_parent();                    /* get task id for master process */
rcode = pvm_recv(mtid, mtype);          /* wait to receive message from master*/
rcode = pvm_upkint(&offset, 1, 1);      /* start pos. in A and C matrices */
rcode = pvm_upkint(&rows, 1, 1);        /* #rows in matrix A sent */
rcode = pvm_upkdouble(a, rows*NCA, 1);  /* our share of matrix A */
rcode = pvm_upkdouble(b, NCA*NCB, 1);   /* contents of matrix B */

printf("worker task id = %d received %d rows from A\n", wtid, rows);

/* do matrix multiply */
for (k=0; k<NCB; k++)
  for (i=0; i<rows; i++) {
    c[i][k] = 0.0;
    for (j=0; j<NCA; j++)
      c[i][k] = c[i][k] + a[i][j] * b[j][k];
  }

/* Set up send message to master. */
mtype = 2;                              /* set message type */
rcode = pvm_initsend(PvmDataDefault);   /* initialize send buffer */
rcode = pvm_pkint(&offset, 1, 1);       /* pos. in result matrix */
rcode = pvm_pkint(&rows, 1, 1);         /* number of rows being sent */
rcode = pvm_pkdouble(c, rows*NCB, 1);   /* our part of result matrix C */

/* send to master */
rcode = pvm_send(mtid, mtype);

/* exit PVM */
rcode = pvm_exit();
}
