/*
 * C�lculo de la suma de cuadrados de los priemros N enteros
 * 
 *
 *   N = (numero de procesadores)*(numero de elementos por fila)
 *
 */

#include <stdio.h>
#include "pvm3.h"

#define MAXNDATA  20
#define MAXNPROCS 16
#define DFLTNDATA 5
#define DFLTNPROCS 4
#define TASK_NAME "trsg"

#define min(x,y) ( ((x)<(y))? (x) : (y) )
#define max(x,y) ( ((x)>(y))? (x) : (y) )

extern void PvmMin();
extern void PvmMax();
extern void PvmSum();
extern void PvmProduct();

void MaxWithLoc();

main()
{
  int myginst, i, j, gsize, count, nprocs, msgtag, datatype; 
  int info_product, info_user; 
  int  tids[MAXNPROCS], myrow[MAXNDATA], matrix[MAXNDATA*MAXNPROCS]; 
  float values[2];
  int midpoint, bigN, Sum1=0, Sum2=0, SumSquares, rootginst; 
  int PSum = 0, PartSums[MAXNPROCS], dupls[MAXNDATA];
  char *gname = "group_rsg";

  /* unirse al grupo */
  myginst = pvm_joingroup(gname);
  pvm_setopt(PvmAutoErr, 1);

  /* Si es el primer miembro obtener las entradas e inicar copias de si mismo */
  if ( myginst == 0 )       
  {
    if (pvm_parent() == PvmNoParent)
    {
      printf("\n *** Ejemplo de uso de PVM Reduce, Scatter, y Gather *** ");
      printf("\n Numero de procesadores (1-%d)? : ", MAXNPROCS);
      scanf("%d", &nprocs);
      if (nprocs > MAXNPROCS) nprocs = MAXNPROCS;
      printf(" Numero de elementos por fila (1-%d)? : ", MAXNDATA);
      scanf("%d", &count);
      if (count > MAXNDATA) count = MAXNDATA;
      printf(" Valores de Entrada: nprocs = %d, count = %d \n", nprocs, count);
    }
    else
    {
      count = DFLTNDATA;
      nprocs = DFLTNPROCS;
    }

    tids[0] = pvm_mytid();

    if (nprocs > 1)
      pvm_spawn(TASK_NAME, (char**)0, 0, "", nprocs-1, &tids[1]);

    /* Esperar a que todos comiencen, enviar los valores de entrada*/
    while (gsize = pvm_gsize(gname) < nprocs) sleep(1);
    pvm_initsend(PvmDataDefault);
    pvm_pkint(&nprocs, 1, 1);
    pvm_pkint(&count,  1, 1);
    pvm_bcast(gname, msgtag=17);
  }
  else
  {
    /* Recibir los valores de entrada */
    pvm_recv(-1, msgtag=17);
    pvm_upkint(&nprocs, 1, 1);
    pvm_upkint(&count,  1, 1);
  }
  
  rootginst = 0;  /* Determinar el root del grupo*/

  /* Iniciar la matriz */
  if (myginst == rootginst) 
    for (j=0; j<nprocs; j++)
      for (i=0; i<count; i++)
        matrix[j*count + i] = j*count + i + 1;

  /* scatter filas de la matriz a cada procesador */
  pvm_scatter(myrow, matrix, count, PVM_INT, msgtag=19, gname, rootginst);

  /* Calcular */
  for (i=0; i<count; i++) dupls[i] = (myginst*count + i + 1);
  datatype = PVM_INT;
  PvmProduct(&datatype, myrow, dupls, &count, &info_product);
  if ((myginst == rootginst) && (info_product < 0))
      printf(" ERROR: %d on PvmProduct call \n", info_product);

  /* Sumas parciales */
  for (i=0; i<count; i++) PSum += myrow[i];

  /* gather sumas parciales */
  pvm_gather(PartSums, &PSum, 1, PVM_INT, msgtag=21, gname, rootginst);

  /* Suma global */
  pvm_reduce(PvmSum, myrow, count, PVM_INT, msgtag=23, gname, rootginst);

  /* Inicializaci�n de Variables en cada procesador */
  midpoint = nprocs/2;
  values[0] = -(myginst - midpoint)*(myginst-midpoint) + count;
  values[1] = myginst;    /* ubicacion */

  /* Funci�n definida en reduce */
  info_user = pvm_reduce(MaxWithLoc, values, 2, PVM_FLOAT, 
                         msgtag=25, gname, rootginst);

  bigN = nprocs*count;
  if (myginst == rootginst)
  {
    /* Metodos para suma de cuadrados */
    for (i=0; i<nprocs; i++) Sum1 += PartSums[i]; 
    for (i=0; i<count;  i++) Sum2 += myrow[i];    
    SumSquares = bigN*(bigN+1)*(2*bigN+1)/6;
    if ( (Sum1 == SumSquares) && (Sum2 == SumSquares))
      printf("\n Test OK: Suma de cuadrados de los primeros %d enteros es %d \n",
             bigN, Sum1);
    else
      printf("\n %s%d%s%d%s%d,\n%s%d \n", 
             "ERROR: La suma de cuadrados del primer ", bigN, 
             " entero \n fue callculado por  Sum1 como ", Sum1,
             " y por Sum2 como ", Sum2,
             " para ambos deber�a de haber sido for ", SumSquares);

    if (info_user < 0) 
      printf(" ERROR: %d en Reduce con Funcion de Usuario\n", info_user);

    if ((values[0] != count) || (values[1] != midpoint)) 
      printf(" ERROR: Deber�a tener (%f, %f), pero tiene (%f, %f): \n",
               count, midpoint, values[0], values[1]);
    else
      printf(" Test Ok: Recibido (%f, %f): ", values[0], values[1]);
    printf("\n");
  }

  /* Sincronizar y salir de pvm */
  pvm_barrier(gname, nprocs);   
  pvm_lvgroup(gname);
  pvm_exit();
  exit(1);

} /* fin main() */


void MaxWithLoc(datatype, x, y, num, info)
int *datatype, *num, *info;
float *x, *y;
{
  int i, count;
  count = (*num) / 2;

  if (*datatype != PVM_FLOAT) { *info = PvmBadParam; return; }

  for (i=0; i<count; i++)
    if (y[i] > x[i])
    {
      x[i]       = y[i];
      x[i+count] = y[i+count];
    }
    else
      if (y[i] == x[i]) x[i+count] = min(x[i+count], y[i+count]);

  *info = PvmOk;
  return;

} 
