#include <stdio.h>
#include "pvm3.h"

#define FIRST   0
#define NTASKS  4

int main() {

int   mytid, tids[NTASKS-1], rank, tag1=1, tag2=2, sum, max, info;

/* Manejo de Grupo */
mytid = pvm_mytid();
rank = pvm_joingroup("summax");
sum = rank;
max = rank;

/* El primero es root */
if (rank == FIRST) {
   info = pvm_spawn("summax", NULL, PvmTaskDefault, "", NTASKS-1, &tids);
   printf("Rank= %d spawned %d tasks\n",rank,info);
   }

/* Barrier de grupo */
pvm_freezegroup("summax",NTASKS);
/* Uso de funcion colectiva */
pvm_reduce(PvmSum,&sum,1,PVM_INT,tag1,"summax",FIRST);
pvm_reduce(PvmMax,&max,1,PVM_INT,tag2,"summax",FIRST);

/* El primero imprime */
if (rank == FIRST) {
   printf("Terminado. Suma= %d  Max= %d\n",sum, max);
   }

/* Todos dejan el grupo */
pvm_barrier("summax",NTASKS);
pvm_lvgroup("summax");
pvm_exit();
}
